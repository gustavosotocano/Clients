package com.example.ClientTenant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientTenantApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientTenantApplication.class, args);
	}

}
