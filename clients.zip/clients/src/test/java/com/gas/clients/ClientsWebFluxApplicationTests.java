package com.gas.clients;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientsWebFluxApplicationTests {

	@Test
	void contextLoads() {
	}

}
